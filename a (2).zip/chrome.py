import os
import subprocess
import zipfile
import urllib.request
import shutil

# Download URLs
chrome_url = "https://storage.googleapis.com/chrome-for-testing-public/145.0.7632.77/linux64/chrome-linux64.zip"
chromedriver_url = "https://storage.googleapis.com/chrome-for-testing-public/145.0.7632.77/linux64/chromedriver-linux64.zip"

# File names for download
chrome_zip = "chrome-linux64.zip"
chromedriver_zip = "chromedriver-linux64.zip"

# Temporary download folder
download_dir = "/tmp/chrome_install"

# Create temporary directory for downloads
if not os.path.exists(download_dir):
    os.makedirs(download_dir)

# Function to download a file
def download_file(url, file_name):
    print(f"Downloading {file_name} from {url}...")
    urllib.request.urlretrieve(url, os.path.join(download_dir, file_name))

# Download Chrome and ChromeDriver
download_file(chrome_url, chrome_zip)
download_file(chromedriver_url, chromedriver_zip)

# Function to extract zip files
def extract_zip(zip_file, extract_to):
    print(f"Extracting {zip_file}...")
    with zipfile.ZipFile(zip_file, 'r') as zip_ref:
        zip_ref.extractall(extract_to)

# Extract Chrome and ChromeDriver
extract_zip(os.path.join(download_dir, chrome_zip), download_dir)
extract_zip(os.path.join(download_dir, chromedriver_zip), download_dir)

# Paths for Chrome and ChromeDriver
chrome_dir = os.path.join(download_dir, "chrome-linux64")
chromedriver_path = os.path.join(download_dir, "chromedriver-linux64", "chromedriver")

# Set destination paths
chrome_dest = "/usr/local/bin/google-chrome"
chromedriver_dest = "/usr/local/bin/chromedriver"

# Copy the extracted Chrome and ChromeDriver to appropriate directories
try:
    print("Copying Google Chrome...")
    shutil.copy2(os.path.join(chrome_dir, "chrome"), chrome_dest)  # Copy Chrome
    shutil.copy2(chromedriver_path, chromedriver_dest)  # Copy ChromeDriver

    # Set executable permissions for the files
    os.chmod(chrome_dest, 0o755)
    os.chmod(chromedriver_dest, 0o755)

    print("Files copied successfully.")

except Exception as e:
    print(f"Error: {e}")

# Verify installations
def check_version(command):
    try:
        result = subprocess.run([command, "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        print(result.stdout.decode())
    except subprocess.CalledProcessError as e:
        print(f"Error running {command}: {e}")

# Check versions of Chrome and ChromeDriver
check_version("google-chrome")
check_version("chromedriver")

# Clean up: Remove downloaded files and extracted folders
shutil.rmtree(download_dir)